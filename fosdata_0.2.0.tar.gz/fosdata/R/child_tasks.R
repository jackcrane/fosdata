#' Shape Trail Test
#'
#' Time that it takes children to complete various activities.
#'
#' More information on the activities of the children.
#' \enumerate{
#'   \item The day-night test. Children are told to say "day" when shown a picture of the moon and stars,
#'   and to say "night" when shown a picture of the sun. Time to complete test and number correct (0 incorrect,
#'   1 point for self-corrected, 2 points for correct) are measured.
#'   \item Counting-span test. Children were required to count the number of red dots on cards, and recall the
#'   number of dots without looking at them. Given in sets of 1 through 5. Max score of 15.
#'   \item Digit Span Backward. Children were read from 2-8 numbers and asked to recite them backwards. Two
#'   numbers repeated 4 times, and the rest repeated twice. Max score of 16.
#'   \item Card-sort task. Children sorted cards that were blue/red with either bunnies/boats on them into boxes
#'   that had either pictures of boats and bunnies or were blue and red. Time to sort and a correctness score
#'   were measured.
#'   \item Shape Trail Test. In trial A the children were to connect the dots in order from 1-15. In trial B
#'   the children were to connect the dots (1-8 circles and 1-7 squares) in order, alternating between circles
#'   and squares. Time to completion was measured.
#' }
#'
#' From the authors: "In this paper we report an initial validation of the Shape Trail Test–Child Version (STT-CV) with a non-clinical sample of children aged 6 to 9 years. The STT-CV has been developed as an age-appropriate and culturally fair direct downward extension of the Trail Making Test (TMT) for the assessment of cognitive flexibility."
#'
#' @format A tibble with 68 observations of 13 variables
#' \describe{
#'   \item{gender}{Factor with levels Male/Female}
#'   \item{age_in_months}{Age in months}
#'   \item{age_group}{Factor with levels "6 year olds", "7 year olds", "8 year olds", "9 year olds"}
#'   \item{day_night_completion_time_secs}{Time to complete day-night test in seconds}
#'   \item{day_night_accuracy_score}{Accuract score in day-night test}
#'   \item{counting_span_score}{Score on counting span test}
#'   \item{backward_digit_span_score}{Score on backward digit test}
#'   \item{card_sort_preswitch_time_secs}{Time to sort cards into boxes with animal labels.}
#'   \item{card_sort_postswitch_time_secs}{Time to sort cards into boxes with colors}
#'   \item{card_sort_preswitch_accuracy}{Accuracy in sorting cards into boxes with animals}
#'   \item{card_sort_postswitch_accuracy}{Accuracy in sorting cards into boxes with colors}
#'   \item{stt_cv_trail_a_secs}{Time to connect dots from 1-15}
#'   \item{stt_cv_trail_b_secs}{Time to connect dots 1-8 and 1-7 alternating circles and squares}
#' }
#'
#' @source Chan AYC, Morgan S-J (2018) Assessing children's cognitive flexibility with the Shape Trail Test. PLoS ONE 13(5): e0198254.
#' @source \url{https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0198254}
"child_tasks"
