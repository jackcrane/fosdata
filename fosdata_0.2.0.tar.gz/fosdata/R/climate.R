#' Citations of Climate Change Papers
#'
#' Does the style of writing impact the number of citations that a climate change paper receives?
#'
#' See the paper for details on how the data was collected. This data set was created using the raw data from
#' the article together with the R script provided by the authors.
#'
#' From the authors: "Peer-reviewed publications focusing on climate change are growing exponentially with the consequence that the uptake and influence of individual papers varies greatly. Here, we derive metrics of narrativity from psychology and literary theory, and use these metrics to test the hypothesis that more narrative climate change writing is more likely to be influential, using citation frequency as a proxy for influence."
#'
#'
#'
#' @format A data frame with 732 observations of 19 variables. Description of variables mostly from the authors.
#' \describe{
#'   \item{appeal}{the moral or evaluative orientation of a narrative. Does the text makes an explicit appeal to the reader or a clear recommendation for action}
#'   \item{conjunctions}{the number of times that conjunctions signifying cause and effect, contrast, or temporal ordering appeared in the text.}
#'   \item{connectivity}{he number of times that words or phrases from one sentence were used to create an explicit link to the sentence immediately preceding it}
#'   \item{narrative_perspective}{whether or not the narrator referred to themselves in the text (e.g., through use of pronouns such as I, we, and our)}
#'   \item{sensory}{the number of times that sensory or emotional language appeared in the abstract}
#'   \item{setting}{whether there is a specific mention of place or time in the abstract}
#'   \item{citations}{The log of Web of Science number of citations for the articles associated with each abstract in our dataset.}
#'   \item{year}{year of publication}
#'   \item{journal}{One of "PNAS" "Proc Roy Soc B" or "Phil Trans Roy Soc B"}
#'   \item{number_of_authors}{number of authors}
#'   \item{abstract_length}{in words}
#'   \item{abstract_number}{unique identifier}
#'   \item{normalized_citations}{adjusted for length of time paper has been published. Citations per year. Not in log scale.}
#'   \item{normalized_sensory}{Sensory words per word in abstract}
#'   \item{normalized_conjunctions}{conjunctions per word in abstract}
#'   \item{normalized_connectivity}{connectivity words per word in abstract}
#'   \item{binary_setting}{1 = yes, 0 = no decision on whether setting is used}
#'   \item{binary_appeal}{1 = yes, 0 = no decision on whether appeal is made}
#'   \item{impact}{impact factor}
#' }
#'
#' @source Hillier A, Kelly RP, Klinger T (2016) Narrative Style Influences Citation Frequency in Climate Change Science. PLoS ONE 11(12): e0167983. https://doi.org/10.1371/journal.pone.0167983
"climate"
