#' Pedal Error Correction
#'
#' From the authors: "Although unintended acceleration caused by pedal misapplication is a cause of traffic accidents, fatal accidents may be avoided if drivers realize their error immediately and quickly correct how they are stepping on the pedal. This correction behavior may decline with age because the rate of fatal accidents is fairly higher for older adults than for younger adults."
#'
#'
#'
#' @format A data frame with 80 observations of 20 variables
#' \describe{
#'   \item{subject_id}{unique identifier of subject}
#'   \item{age_group}{Young or Old}
#'   \item{age}{age in years}
#'   \item{gender}{1 = male, 0 = female}
#'   \item{latency_p1}{time to press brake after seeing red light (ms)}
#'   \item{latency_p2}{time to release brake after pressing on it (ms)}
#'   \item{latency_p3}{time to press pedal to left of what participant thought was brake (ms)}
#'   \item{p1_p2}{Sum of latency_p1 and latency_p2}
#'   \item{p1_p2_p3}{Sum of latency_p1, latency_p2, and latency_p3}
#'   \item{cfq}{Score on cognitive failure questionairre}
#'   \item{dbq_error}{Score on dribing behavior questionnaire error questions}
#'   \item{dbq_violation}{Score on dbq violation questions}
#'   \item{dbq_laspe}{Score on dbq lapse questions}
#'   \item{difficulty}{response to "was the current task difficult for you" on a 1-100 visual scale}
#'   \item{confidence}{response to "do you have much confidence in your ability to perform the current task" 1-100}
#'   \item{decline}{asked of older adults. "how well do you think you can perform task relative to younger adults" scale from 1-150}
#'   \item{anxiety}{In daily life, how much are you afraid you will press the wrong pedal? 1-5}
#'   \item{near_miss}{In daily life, how often do you nearly miss the pedal? 1-5}
#'   \item{mmse}{Score on mini mental stat examination (24 necessary to participate)}
#'   \item{education}{numeric 12-20}
#' }
#'
#' @source Hasegawa K, Kimura M, Takeda Y (2020) Age-related differences in correction behavior for unintended acceleration. PLoS ONE 15(7): e0236053.
#' @source \url{https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0236053}
#' @source \url{https://osf.io/mre6y/?view_only=5af130ecc3234435b7a7ffc1ba6c391f}
"brake"
